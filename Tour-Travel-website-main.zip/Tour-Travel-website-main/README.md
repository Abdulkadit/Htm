# Travel-website
✈️ A Simple Tour or Travel Booking Website using Html, Css &amp; Javascript Hello there, I'm Aabida alalawi and I made this Tour&amp;travel Booking Website. 
🌐 This Website is made with Html, CSS &amp; Javascript. It contains a Homepage with travel destination all over world and much more.
It contains NavBar,MenuBar,booking form,Header &amp; Footer as well. 
It has different modules in overall page from Book,Services,Destination,Galley,Blog &amp; Contact. 
Basic Html &amp; CSS plays an important role here making whole website more attractive and responsive for all devices. 
Different packages are included to make website user friendly and more responsive towards making their trip more comfortable, luxurious and safer.
A Navigation Scroll Bar will be their which will we Helpfull seeing Images throughout Web Page &amp; Scrolling Web Page.
